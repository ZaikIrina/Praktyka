/**
 * Displays results as a table
 */
public class TableView implements ResultView {

    protected int width;

    /**
     * Constructor
     */
    public TableView(int width) {
        this.width = width;
    }

    /**
     * Overridden method
     */
    @Override
    public void show(ResultData data) {

        System.out.printf("%-" + width + "s %-" + width + "s %-" + width + "s\n",
                "Base", "Height", "Ones");

        System.out.printf("%-" + width + ".2f %-" + width + ".2f %-" + width + "d\n",
                data.a, data.h, data.ones);
    }
}