/**
 * Factory that creates table view
 */
public class TableFactory implements ViewFactory {

    @Override
    public ResultView createView(int width) {

        return new PrettyTableView(width);
    }
}