/**
 * Extended table view
 */
public class PrettyTableView extends TableView {

    public PrettyTableView(int width) {
        super(width);
    }

    /**
     * Overridden method
     */
    @Override
    public void show(ResultData data) {

        System.out.println("================================");

        super.show(data);

        System.out.println("================================");
    }
}