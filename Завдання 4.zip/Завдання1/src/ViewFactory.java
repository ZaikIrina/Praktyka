/**
 * Factory interface
 */
public interface ViewFactory {

    ResultView createView(int width);
}