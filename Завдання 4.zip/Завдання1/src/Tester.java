/**
 * Class for testing functionality
 */
public class Tester {

    /**
     * Method overloading example
     */
    public void test(ResultData data) {

        System.out.println("Testing result: " + data.ones);
    }

    /**
     * Overloaded method
     */
    public void test(double a, double h) {

        ResultData data = Calculator.calculate(a,h);

        test(data);
    }
}