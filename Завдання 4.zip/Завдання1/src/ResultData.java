import java.io.Serializable;

/**
 * Class that stores parameters and results of calculations
 */
public class ResultData implements Serializable {

    public double a;
    public double h;
    public int ones;

    /**
     * Constructor
     */
    public ResultData(double a, double h, int ones) {
        this.a = a;
        this.h = h;
        this.ones = ones;
    }
}