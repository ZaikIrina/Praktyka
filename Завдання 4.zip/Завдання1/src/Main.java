import java.util.Scanner;

/**
 * Main program class
 */
public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter base: ");
        double a = scanner.nextDouble();

        System.out.print("Enter height: ");
        double h = scanner.nextDouble();

        System.out.print("Enter table column width: ");
        int width = scanner.nextInt();

        ResultData data = Calculator.calculate(a,h);

        ViewFactory factory = new TableFactory();

        ResultView view = factory.createView(width);

        view.show(data);

        Tester tester = new Tester();

        tester.test(data);

        scanner.close();
    }
}