package ex03;

import ex02.View;

/**
 * Factory interface
 */
public interface Viewable {

    View getView();
}