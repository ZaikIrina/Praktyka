package ex02;

/**
 * View interface
 */
public interface View {

    void viewInit();

    void viewShow();
}