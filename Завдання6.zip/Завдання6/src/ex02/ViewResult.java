package ex02;

import ex01.Item2d;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Stores collection of items
 */
public class ViewResult implements View {

    private List<Item2d> items = new ArrayList<>();

    private int size = 10;

    public ViewResult() {}

    public ViewResult(int size) {
        this.size = size;
        viewInit();
    }

    public List<Item2d> getItems() {
        return items;
    }

    @Override
    public void viewInit() {

        items.clear();
        Random r = new Random();

        for(int i=0;i<size;i++){
            items.add(new Item2d(r.nextDouble()*100-50));
        }
    }

    @Override
    public void viewShow() {

        System.out.println("Items:");

        for(Item2d item : items){
            System.out.println(item);
        }
    }
}