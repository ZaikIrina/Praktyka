package ex02;

import ex03.Viewable;

/**
 * Factory method implementation
 */
public class ViewableResult implements Viewable {

    @Override
    public View getView() {
        return new ViewResult(10);
    }
}