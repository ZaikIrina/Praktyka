package ex05;

import ex02.ViewResult;
import ex04.Command;

/**
 * Average calculation (Worker Thread)
 */
public class AvgCommand implements Command {

    private double result = 0;
    private boolean done = false;
    private ViewResult view;

    public AvgCommand(ViewResult view) {
        this.view = view;
    }

    public double getResult() {
        return result;
    }

    public boolean isDone() {
        return done;
    }

    @Override
    public void execute() {

        System.out.println("Average started...");

        result = 0;

        for(var item : view.getItems()){
            result += item.getY();
        }

        result /= view.getItems().size();

        System.out.println("Average = " + result);

        done = true;
    }
}