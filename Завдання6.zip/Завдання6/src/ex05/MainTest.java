package ex05;

import ex02.ViewResult;

/**
 * Simple test class
 */
public class MainTest {

    public static void main(String[] args) {

        ViewResult view = new ViewResult(10);

        CommandQueue queue = new CommandQueue();

        queue.put(new MaxCommand(view));
        queue.put(new AvgCommand(view));
        queue.put(new MinMaxCommand(view));
    }
}