package ex05;

import ex04.Command;

/**
 * Queue interface (Worker Thread)
 */
public interface Queue {

    void put(Command cmd);

    Command take();
}