package ex05;

import ex02.View;
import ex02.ViewResult;
import ex04.ConsoleCommand;

/**
 * Execute all commands (parallel)
 */
public class ExecuteConsoleCommand implements ConsoleCommand {

    private View view;

    public ExecuteConsoleCommand(View view) {
        this.view = view;
    }

    @Override
    public char getKey() {
        return 'e';
    }

    @Override
    public String toString() {
        return "execute";
    }

    @Override
    public void execute() {

        CommandQueue q1 = new CommandQueue();
        CommandQueue q2 = new CommandQueue();

        MaxCommand max = new MaxCommand((ViewResult)view);
        AvgCommand avg = new AvgCommand((ViewResult)view);
        MinMaxCommand minmax = new MinMaxCommand((ViewResult)view);

        System.out.println("Running threads...");

        q1.put(minmax);
        q2.put(max);
        q2.put(avg);
    }
}