package ex05;

import ex02.ViewResult;
import ex04.Command;

/**
 * Min and Max calculation
 */
public class MinMaxCommand implements Command {

    private double min, max;
    private boolean done = false;
    private ViewResult view;

    public MinMaxCommand(ViewResult view) {
        this.view = view;
    }

    @Override
    public void execute() {

        System.out.println("MinMax started...");

        min = max = view.getItems().get(0).getY();

        for(var item : view.getItems()){
            if(item.getY() < min) min = item.getY();
            if(item.getY() > max) max = item.getY();
        }

        System.out.println("Min = " + min);
        System.out.println("Max = " + max);

        done = true;
    }
}