package ex05;

import ex02.ViewResult;
import ex04.Command;

/**
 * Max value calculation
 */
public class MaxCommand implements Command {

    private double result;
    private boolean done = false;
    private ViewResult view;

    public MaxCommand(ViewResult view) {
        this.view = view;
    }

    public double getResult() {
        return result;
    }

    public boolean isDone() {
        return done;
    }

    @Override
    public void execute() {

        System.out.println("Max started...");

        result = view.getItems().get(0).getY();

        for(var item : view.getItems()){
            if(item.getY() > result)
                result = item.getY();
        }

        System.out.println("Max = " + result);

        done = true;
    }
}