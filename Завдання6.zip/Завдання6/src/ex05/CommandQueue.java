package ex05;

import java.util.LinkedList;
import ex04.Command;

/**
 * Worker Thread implementation
 */
public class CommandQueue implements Queue {

    private LinkedList<Command> list = new LinkedList<>();

    public CommandQueue() {

        new Thread(() -> {
            while(true){
                Command cmd = take();
                cmd.execute();
            }
        }).start();
    }

    @Override
    public synchronized void put(Command cmd) {
        list.add(cmd);
        notify();
    }

    @Override
    public synchronized Command take() {

        while(list.isEmpty()){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return list.removeFirst();
    }
}