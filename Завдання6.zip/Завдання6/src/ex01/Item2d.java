package ex01;

/**
 * Simple data class
 */
public class Item2d {

    private double y;

    public Item2d(double y) {
        this.y = y;
    }

    public double getY() {
        return y;
    }

    @Override
    public String toString() {
        return String.format("%.2f", y);
    }
}