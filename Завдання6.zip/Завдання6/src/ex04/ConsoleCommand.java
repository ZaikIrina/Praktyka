package ex04;

/**
 * Console command interface
 */
public interface ConsoleCommand {

    char getKey();

    void execute();

    String toString();
}