package ex04;

/**
 * Command interface
 */
public interface Command {

    void execute();
}