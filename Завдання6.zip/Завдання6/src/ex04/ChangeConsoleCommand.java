package ex04;

import ex02.View;

/**
 * Change data (simple regenerate)
 */
public class ChangeConsoleCommand implements ConsoleCommand {

    private View view;

    public ChangeConsoleCommand(View view) {
        this.view = view;
    }

    public char getKey() { return 'c'; }

    public String toString() { return "change"; }

    public void execute() {
        view.viewInit();
        System.out.println("Changed");
    }
}