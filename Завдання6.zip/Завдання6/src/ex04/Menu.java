package ex04;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Menu (macro command)
 */
public class Menu {

    private List<ConsoleCommand> commands = new ArrayList<>();

    public void add(ConsoleCommand c) {
        commands.add(c);
    }

    public void execute() {

        Scanner sc = new Scanner(System.in);

        while(true){

            System.out.println("\nMenu:");

            for(ConsoleCommand c : commands){
                System.out.println(c.getKey() + " - " + c);
            }

            System.out.println("0 - exit");

            char key = sc.next().charAt(0);

            if(key == '0') break;

            for(ConsoleCommand c : commands){
                if(c.getKey() == key){
                    c.execute();
                }
            }
        }
    }
}