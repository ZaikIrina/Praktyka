package ex04;

import ex02.View;

/**
 * Generate data
 */
public class GenerateConsoleCommand implements ConsoleCommand {

    private View view;

    public GenerateConsoleCommand(View view) {
        this.view = view;
    }

    public char getKey() { return 'g'; }

    public String toString() { return "generate"; }

    public void execute() {
        view.viewInit();
        System.out.println("Generated");
    }
}