package ex04;

import ex02.View;

/**
 * Show data
 */
public class ViewConsoleCommand implements ConsoleCommand {

    private View view;

    public ViewConsoleCommand(View view) {
        this.view = view;
    }

    public char getKey() { return 'v'; }

    public String toString() { return "view"; }

    public void execute() {
        view.viewShow();
    }
}